from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'ThisIsASecret'

noName = 'Please enter your Name'
tooLong = 'Please keep your comment under 120 characters'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/users', methods=['POST'])
def create_user():
    session['name'] = request.form['name']
    if len(session['name']) < 1:
        session['name'] = noName
    session['location'] = request.form['location']
    session['language'] = request.form['language']
    session['comment'] = request.form['comment']
    if len(session['comment']) > 120:
        session['comment'] = tooLong
    return redirect('/result')

@app.route('/result')
def result():
    return render_template('result.html')
app.run(debug=True)
