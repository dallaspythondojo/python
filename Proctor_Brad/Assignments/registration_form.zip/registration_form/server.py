from flask import Flask, render_template, redirect, request, session, flash
import re

app = Flask(__name__)
app.secret_key = '238975nds8fjvnjw498t'

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
NAME_REGEX = re.compile(r'^[a-zA-Z]')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process():
    if len(request.form['first']) < 1:
        flash('Enter your first name sucka!')
    elif len(request.form['last']) < 1:
        flash('Enter your last name sucka!')
    elif len(request.form['email']) < 1:
        flash('Enter your email sucka!')
    elif len(request.form['password']) < 1:
        flash('Enter your password sucka!')
    elif len(request.form['confirm']) < 1:
        flash('Confirm your password sucka!')
    elif not NAME_REGEX.match(request.form['first']):
        flash("Your first name can't contain a number sucka!")
    elif not NAME_REGEX.match(request.form['last']):
        flash("Your last name can't contain a number sucka!")
    elif not EMAIL_REGEX.match(request.form['email']):
        flash('Fix your email sucka!')
    elif len(request.form['password']) < 8:
        flash("Your password ain't long enough sucka!")
    elif request.form['password'] != request.form['confirm']:
        flash('Make your passwords confirm sucka!')
    else:
        flash('Thanks for submitting your information.')

    return redirect('/')

app.run(debug=True)
