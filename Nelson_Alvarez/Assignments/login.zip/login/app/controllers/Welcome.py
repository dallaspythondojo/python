from system.core.controller import *

class Welcome(Controller):
    def __init__(self, action):
        super(Welcome, self).__init__(action)
      
        self.load_model('WelcomeModel')
        self.db = self._app.db

   
    def index(self):
        return self.load_view('index.html')

    def login(self):
        user = {
            'email': request.form['email'],
            'password': request.form['password']
        }
        log = self.models['WelcomeModel'].check_login(user)
        if log['status'] == False:
            flash(log['error'], 'regis_errors')
            return redirect('/')
        else:
            session['logged'] = 'Logged in'
            session['user'] = log['user']
            return redirect('/success')

    def create(self):
        user = {
            'first': request.form['first'],
            'last': request.form['last'],
            'email': request.form['email'],
            'password': request.form['pwd'],
            'passcon': request.form['passcon']
        }
        create = self.models['WelcomeModel'].register(user)
        if create['status'] == False:
            for message in create['errors']:
                flash(message, 'regis_errors')
            return redirect('/')
        else:
            session['logged'] = 'Registered'
            session['user'] = create['user']
            return redirect('/success')

    def success(self):
        if not 'user' in session:
            return redirect('/')
        return self.load_view('success.html', user=session['user']['first_name'], logged=session['logged'])

    def login(self):
        data = {
            'email': request.form['email'],
            'password': request.form['password']
        }
        log = self.models['WelcomeModel'].check_login(data)
        if log['status'] == False:
            flash(log['error'], 'regis_errors')
            return redirect('/')
        else:
            session['logged'] = 'Logged in'
            session['user'] = log['user']
            return redirect('/success')

    def logout(self):
        session.clear()
        return redirect('/')