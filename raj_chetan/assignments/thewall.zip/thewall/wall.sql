-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: wall
-- ------------------------------------------------------
-- Server version	5.7.15-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `message_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comment_message_idx` (`message_id`),
  KEY `fk_comment_user1_idx` (`user_id`),
  CONSTRAINT `fk_comment_message` FOREIGN KEY (`message_id`) REFERENCES `message` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_comment_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'this is the first comment for the fourth post by user id 3','2016-10-12 16:57:15','2016-10-12 16:57:15',4,3),(2,'this is the 1st comment on the fifth post by the 3rd user','2016-10-12 17:07:07','2016-10-12 17:07:07',5,3),(3,'this is the 2nd comment on the 5th post by the 3rd user','2016-10-12 17:07:20','2016-10-12 17:07:20',5,3),(4,'this is the 3rd comment on the 5th post by the 3rd user','2016-10-12 17:07:35','2016-10-12 17:07:35',5,3),(5,'this is a comment on the 1st post by the 3rd user. ','2016-10-12 17:07:53','2016-10-12 17:07:53',1,3),(6,'this is a comment on the 4th post by user id 4','2016-10-12 17:30:26','2016-10-12 17:30:26',4,4),(7,'this is a comment on the 1st post by user id 4','2016-10-12 17:30:37','2016-10-12 17:30:37',1,4);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `messages` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_message_user1_idx` (`user_id`),
  CONSTRAINT `fk_message_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,'this is the first post','2016-10-12 15:53:26','2016-10-12 15:53:26',3),(2,'haijsdflksd  fasdf','2016-10-12 16:00:36','2016-10-12 16:00:36',3),(3,'news.google.com','2016-10-12 16:20:12','2016-10-12 16:20:12',3),(4,'this is the fourth post.','2016-10-12 16:30:06','2016-10-12 16:30:06',3),(5,'this is the fifth post by the 3rd user','2016-10-12 17:06:47','2016-10-12 17:06:47',3),(6,'this is the 6th post and it was made by user ID 4','2016-10-12 17:29:43','2016-10-12 17:29:43',4),(7,'Hi guys! I just won a noble prize! :D','2016-10-13 10:15:42','2016-10-13 10:15:42',5);
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `plaintext` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'chetan','raj','chetan@dfsdfd.com','$2b$12$qVRtp6ozw7lXQViLwjbZSONAwlYA3OTEfQCLOUtAMdwrJ8aEpUc2e','mypassword','2016-10-12 15:40:19','2016-10-12 15:40:19'),(3,'First','Last','email@email.com','$2b$12$2pzVywm4qJzZ2d.E.vTeIOk861JMmezudeaqGqTCPI2Upv5iFa.I2','mypassword','2016-10-12 15:40:42','2016-10-12 15:40:42'),(4,'user','two','user@user.com','$2b$12$9Vy.PCKkVwMo.Yks7r0TfuphUCRrP0tYj26xSSuIVJ5cwMa8y8Epe','mypassword','2016-10-12 17:29:04','2016-10-12 17:29:04'),(5,'Bob','Dylan','bob@dylan.com','$2b$12$Sm5WyvGSOkNA3QYtFW.KRu/VS6ezM8Ngq.kJiZA3PNbjpPM0N0Kze','mypassword','2016-10-13 10:15:19','2016-10-13 10:15:19');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-13 10:20:58
