from flask import Flask, request, redirect, session, render_template, flash 
from mysqlconnection import MySQLConnector
import re
from flask_bcrypt import Bcrypt 
import datetime

app = Flask(__name__)
mysql = MySQLConnector(app, 'wall')
app.secret_key = 'wallsecretkey'
bcrypt = Bcrypt(app)

name_regex = re.compile(r'^[A-Za-z]+$')
email_regex =  re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9.+_-]+\.[a-zA-Z]+$')

@app.route('/')
def index():
	
	# if 'user' in session:
	# 	return redirect('/wall')
	return render_template('index.html')



@app.route('/wall')
def wall():
	if not 'user' in session:
		flash("You are not allowed to access that page")
		return redirect('/')

	all_messages = mysql.query_db("SELECT message.id, message.messages, user.first_name, user.last_name, DATE_FORMAT(message.created_at,'on %b %d %Y at %h:%i') date FROM message JOIN user ON user.id = message.user_id ORDER BY message.created_at DESC")
	all_comments = mysql.query_db("SELECT comment.id, comment.comment, user.id as 'uid', user.first_name, DATE_FORMAT(comment.created_at, '%b %d %Y at %h:%i') commentdate, message.id as 'mid' FROM comment LEFT JOIN user on comment.user_id = user.id left JOIN message on comment.message_id = message.id ORDER BY comment.created_at DESC")
	return render_template('wall.html', all_messages = all_messages, all_comments = all_comments)



@app.route('/process', methods = ['POST'])
def process():
	if 'register' in request.form:
		valid_register = True
		if name_regex.match(request.form['first_name']) and (len(request.form['first_name']) > 1):
			first_name = request.form['first_name']
		else:
			flash("First name entry is not valid.")
			valid_register = False
		if name_regex.match(request.form['last_name']) and (len(request.form['last_name']) > 1):
			last_name = request.form['last_name']
		else:
			flash("Last name entry is not valid.")
			valid_register = False
		if email_regex.match(request.form['email']):
			email = request.form['email']
		else:
			flash("Email is not valid.")
			valid_register = False
		if (request.form['password'] == request.form['confirm']) and (len(request.form['password']) > 8):
			plain_text_pw = request.form['password']
			encrypted_pw = bcrypt.generate_password_hash(plain_text_pw)
		else:
			flash("Password entry error.")
			valid_register = False

		if valid_register:
			query = "INSERT INTO user (first_name, last_name, email, password, plaintext, created_at, updated_at) VALUES (:first_name, :last_name, :email, :password, :plaintext, NOW(), NOW())"
			data = {
				'first_name': first_name,
				'last_name': last_name,
				'email': email,
				'password': encrypted_pw,
				'plaintext': plain_text_pw
			}
			mysql.query_db(query, data)
			flash("User {} {} successfully added to database at {}".format(first_name, last_name, datetime.datetime.now()))
			return redirect('/')
		else: 
			flash("There was an error with your user registration. Please try again.")
			return redirect('/')

	if 'login_hidden' in request.form:
		user_login_query = "SELECT * FROM user where email = :email LIMIT 1"
		data_login_query = {'email': request.form['email']}
		user_checkout = mysql.query_db(user_login_query, data_login_query)
		if len(user_checkout) == 0:
			flash("Please enter a valid email address")
			return redirect('/')
		if bcrypt.check_password_hash(user_checkout[0]['password'], request.form['loginpw']):
			session['user'] = user_checkout[0]
			return redirect('/wall')
		else:
			flash("Error with email or email/password combination")
			return redirect('/')

	if 'logout_hidden' in request.form:
		session.pop('user')
		return redirect('/')

@app.route('/message', methods = ['POST'])
def message():
	current_user_id = int(session['user']['id'])
	if 'post_message_hidden' in request.form:
		if (len(request.form['post_message_textarea']) > 1):
			entered_post = request.form['post_message_textarea']
			print entered_post
			print current_user_id
			query = "INSERT INTO message (messages, created_at, updated_at, user_id) VALUES (:messages, NOW(), now(), :user_id)"
			data = {
				'messages': entered_post,
				'user_id': current_user_id
			}
			mysql.query_db(query, data)
			return redirect('/wall')
		else:
			flash("Please enter a longer message")
			return redirect('/wall')

@app.route('/comment', methods = ['POST'])
def comment():
	current_user_id = int(session['user']['id'])
	if 'post_comment_hidden' in request.form:
		belongs_to_message = request.form['post_comment_hidden']
		query = "INSERT INTO comment (comment, created_at, updated_at, message_id, user_id) VALUES (:comment, now(), now(), :message_id, :user_id)"
		data = {
			'comment': request.form['post_comment_textarea'],
			'message_id': belongs_to_message,
			'user_id': current_user_id
		}
		mysql.query_db(query, data)
		# print request.form['post_comment_hidden']
		# print request.form['post_comment_textarea']
		return redirect('/wall')


app.run(debug=True)

'''
SQL Query test 

select user.id as 'uid', user.first_name, user.last_name, user.email, message.id as 'mid', message.messages, message.created_at, comment.id as 'cid', comment.comment, comment.created_at from user
join message on message.user_id = user.id
left join comment on comment.user_id = user.id
'''
